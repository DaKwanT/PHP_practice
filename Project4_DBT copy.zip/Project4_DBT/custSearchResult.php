<html>
<head>
<title>Customer Search Result</title>
</head>
<body>

<?php echo'<p><h1>These were all the customers found</h1></p>';

	//Set the DB connection
	require_once 'login.php';
	$conn= new mysqli($hn,$un,$pw,$db);
	if($conn->connect_error)die($conn->connect_error);
//construct the SQL sequence
	
	$SQL= "select* from customers where CustID=CustID ";
	
if (($_POST['CustID'])!= "") 
{ 
	$CustIDvar = mySQL_fix_string($conn, $_POST['CustID']);
	$SQL = $SQL . " and CustID = '$CustIDvar'";
}
else
	{ $CustIDvar = "";
}
if (($_POST['CustName'])!= "") 
{ 
	$CustNamevar = mySQL_fix_string($conn, $_POST['CustName']);
	$SQL = $SQL . " and CustName = '$CustNamevar'";
}
else
	{ $CustNamevar = "";
}
if (($_POST['city'])!= "") 
	{ 
	$Cityvar = mySQL_fix_string($conn, $_POST['city']);
	if ($Cityvar != "" ) 	$SQL = $SQL . " and city = '$Cityvar'";
	}
else
	{ $Cityvar = "";
}
if (($_POST['phone'])!= "") 
	{ 
	$Phonevar = mySQL_fix_string($conn, $_POST['phone']);
	$SQL = $SQL . " and phone = '$Phonevar'";
	}
else
	{ $Phonevar = "";
}
	//setting the variable for the next N Records button
if (isset($_POST['start'])) 
	{ 
	$start = mySQL_fix_string($conn, $_POST['start']);
	}
else
	{
	$start = 0;
	}

	//run the SQL to search DB
$result = $conn->query($SQL);
if (!$result) die("Database access failed: " . $conn->error);

	//
	//display the results
	//
$rows = $result->num_rows;
	//set max records for viewing
$maxRecs = 3;
	//compute current max Recs for loop
$currMaxRecs = $maxRecs + $start;
if ($currMaxRecs > $rows)
{
	$currMaxRecs = $rows;
	//because we cannot go past our recordset max
}
echo '<h3>A total of ' . $rows . ' customers found <h3>' . '<br>';



for ($j=$start; $j < $currMaxRecs; ++$j)
{
	$result->data_seek($j);
	$row = $result->fetch_array(MYSQLI_ASSOC);
		
		echo'<form action = "OrderResult.php" method="post">';
		echo 'Record No. ' . ($j + 1) . '<br>';
		echo 'CustID: '	. $row['CustID'] . '<br>';
		echo 'CustName: ' . $row['CustName'] . '<br>';
		echo 'City: ' . $row['city'] . '<br>';
		echo 'phone: ' . $row['phone'] . '<br><br>';
		echo '<input type="hidden" name="CustIDHidden" value="'.$row['CustID'].'">'.'<br>';
		echo '<input type="submit" value="See Customer Orders">'.'<br>';
		echo '<hr>';
		echo'</form>';
}
//next N Records code for the Next N button
//note that we recursively call up the same file, this file
echo '<form action = "CustSearchResult.php" method = "post">';
		$nextStart = $start + $maxRecs;
		echo '<input type = "hidden" name = "start" value = "' . $nextStart . '"' . ' <br>';
		//check to see if search variable exists, if so, then submit for search again
		if (isset($_POST['CustID'])) 
		{
			echo '<input type = "hidden" name = "CustID" value = "' . $CustIDvar . '"' . '>';
		}
		if (isset($_POST['CustName'])) 
		{
			echo '<input type = "hidden" name = "CustName" value = "' . 
						$CustNamevar . '"' . '>';
		}
	 	if (isset($_POST['city'])) 
		{
			echo '<input type = "hidden" name = "city" value = "' . $Cityvar . '"' . '>';
		}
		if (isset($_POST['phone'])) 
		{
			echo '<input type = "hidden" name = "phone" value = "' . $Phonevar . '"' . '>';
		}
		echo '<input type="submit" value = "Next 3 Records">' . '<br>';
echo '</form>';
//
//close the DB connection and query
		
		$result->close();
		$conn->close();
function mysql_fix_string($conn, $string)
{
	if (get_magic_quotes_gpc()) $string = stripslashes($string);
	return $conn->real_escape_string($string);
}
?>
</body>
</html>
