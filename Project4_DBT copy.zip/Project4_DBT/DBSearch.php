<html>
<head>
<title>Customer Search by DB</title>
</head>
<body>

<?php echo '<p><h1>Search for Customer DB menu</h1></p>';
	//establish a connection
	require_once 'login.php';
	$conn=new mysqli($hn,$un,$pw,$db);
	if($conn->connect_error)die($conn->connect_error);

	$SQL="select distinct city from customers";
	$result=$conn->query($SQL);
	if(!$result)die($conn->connect_error);

	$rows=$result->num_rows;
	//header

	//this time we will add a dynamic list box, Select

echo<<<_END
		<form action="custSearchResult.php"method="post">
			CustID: <input type="text" name="CustID">
			CustName: <input type="text" name="CustName">
			city:	<select name="city">
				<option>
			

_END;
		for($j =0;$j <$rows;++$j)
			{
				$result->data_seek($j);
				$row=$result->fetch_array(MYSQLI_NUM);
				$city=$row[0];	//first field of the row
				echo '<option>'.$city.'</option>';
			}
echo<<<_END
		</select>
			
			Phone: <input type="text" name="phone">
			<input type="submit" value="Search for Customers">
			<input type="reset" value="Clear">


_END;
	
		//close the DB connection and query

		$result->close();
		$conn->close();
?>
</body>
</html>