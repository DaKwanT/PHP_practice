<?php //login.php
	$hn = '127.0.0.1';
	$db = 'customerdb';
	$un = 'student';
	$pw = '';
?>	
   
