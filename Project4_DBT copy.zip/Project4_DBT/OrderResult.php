<html>
<head>
<title>Customer Order Results</title>
</head>
<body>

<?php

	require_once 'login.php';
	$conn= new mysqli($hn, $un, $pw, $db);
	if ($conn->connect_error)die($conn->connect_error);

		if(($_POST['CustIDHidden'])!="")
	{
		$CustIDVar=$_POST['CustIDHidden'];
	}

	//define $SQL

	$SQL="select customers.CustID, customers.CustName, orders.orderDate,";
	$SQL=$SQL." orderDetails.productID, orderDetails.quantity ";
	$SQL=$SQL."from customers, orderDetails, orders ";
	$SQL=$SQL."where customers.CustID = orders.CustID and ";
	$SQL=$SQL."orders.orderID = orderDetails.orderID and ";
	$SQL=$SQL."customers.CustID = '$CustIDVar'";


	//establish the result

	$result= $conn-> query($SQL);
	if (!$result) die($conn->connect_error);

	//get the number of results

	$rows = $result->num_rows;

	echo '<h3>A total of ' . $rows . ' customers found <h3>' . '<br>';
	
	for ($j=0; $j < $rows; ++$j)
	
	{

		$result->data_seek($j);

	//Fetch the records

	$row =$result->fetch_array(MYSQLI_ASSOC);

	//access each field

	echo'<b>CustID:'.$row['CustID'].'<br></b>';
	echo'<b>CustName:'.$row['CustName'].'<br></b>';
	echo'<b>order Date:'.$row['orderDate'].'<br></b>';
	echo'<b>ProductID:'.$row['productID'].'<br></b>';
	echo'<b>quantity:'.$row['quantity'].'<br></b><hr>';
}

//close all connections

	$result->close();
	$conn->close();

	?>
</body>
</html>

	

	